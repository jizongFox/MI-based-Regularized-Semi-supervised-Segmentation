from collections import OrderedDict

import torch
import torch.nn as nn
import torch.nn.functional as F


class _DenseLayer(nn.Sequential):
    def __init__(self, num_input_features, growth_rate, bn_size, drop_rate):
        super(_DenseLayer, self).__init__()
        self.add_module("norm1", nn.BatchNorm3d(num_input_features)),
        self.add_module("relu1", nn.ReLU(inplace=True)),
        self.add_module(
            "conv1",
            nn.Conv3d(
                num_input_features,
                bn_size * growth_rate,
                kernel_size=1,
                stride=1,
                bias=False,
            ),
        ),
        self.add_module("norm2", nn.BatchNorm3d(bn_size * growth_rate)),
        self.add_module("relu2", nn.ReLU(inplace=True)),
        self.add_module(
            "conv2",
            nn.Conv3d(
                bn_size * growth_rate,
                growth_rate,
                kernel_size=3,
                stride=1,
                padding=1,
                bias=False,
            ),
        ),
        self.drop_rate = drop_rate

    def forward(self, x):
        new_features = super(_DenseLayer, self).forward(x)
        if self.drop_rate > 0:
            new_features = F.dropout(
                new_features, p=self.drop_rate, training=self.training
            )
        return torch.cat([x, new_features], 1)


class _DenseBlock(nn.Sequential):
    def __init__(self, num_layers, num_input_features, bn_size, growth_rate, drop_rate):
        super(_DenseBlock, self).__init__()
        for i in range(num_layers):
            layer = _DenseLayer(
                num_input_features + i * growth_rate, growth_rate, bn_size, drop_rate
            )
            self.add_module("denselayer%d" % (i + 1), layer)


class _Transition(nn.Sequential):
    def __init__(self, num_input_features, num_output_features):
        super(_Transition, self).__init__()
        self.add_module("norm", nn.BatchNorm3d(num_input_features))
        self.add_module("relu", nn.ReLU(inplace=True))
        self.add_module(
            "conv",
            nn.Conv3d(
                num_input_features,
                num_output_features,
                kernel_size=1,
                stride=1,
                bias=False,
            ),
        )

        self.add_module("pool_norm", nn.BatchNorm3d(num_output_features))
        self.add_module("pool_relu", nn.ReLU(inplace=True))
        self.add_module(
            "pool",
            nn.Conv3d(
                num_output_features, num_output_features, kernel_size=2, stride=2
            ),
        )


class DenseNet(nn.Module):
    r"""Densenet-BC model class, based on
    `"Densely Connected Convolutional Networks" <https://arxiv.org/pdf/1608.06993.pdf>`_

    Args:
        growth_rate (int) - how many filters to add each layer (`k` in paper)
        block_config (list of 4 ints) - how many layers in each pooling block
        num_init_features (int) - the number of filters to learn in the first convolution layer
        bn_size (int) - multiplicative factor for number of bottle neck layers
          (i.e. bn_size * k features in the bottleneck layer)
        drop_rate (float) - dropout rate after each dense layer
        num_classes (int) - number of classification classes
    """

    def __init__(
        self,
        input_dim=2,
        growth_rate=16,
        block_config=(6, 12, 24, 16),
        num_init_features=32,
        bn_size=4,
        drop_rate=0,
        num_classes=9,
    ):
        super(DenseNet, self).__init__(input_dim, num_classes)

        # First three convolutions
        self.features = nn.Sequential(
            OrderedDict(
                [
                    (
                        "conv0",
                        nn.Conv3d(
                            input_dim,
                            num_init_features,
                            kernel_size=3,
                            stride=1,
                            padding=1,
                            bias=False,
                        ),
                    ),
                    ("norm0", nn.BatchNorm3d(num_init_features)),
                    ("relu0", nn.ReLU(inplace=True)),
                    (
                        "conv1",
                        nn.Conv3d(
                            num_init_features,
                            num_init_features,
                            kernel_size=3,
                            stride=1,
                            padding=1,
                            bias=False,
                        ),
                    ),
                    ("norm1", nn.BatchNorm3d(num_init_features)),
                    ("relu1", nn.ReLU(inplace=True)),
                    (
                        "conv2",
                        nn.Conv3d(
                            num_init_features,
                            num_init_features,
                            kernel_size=3,
                            stride=1,
                            padding=1,
                            bias=False,
                        ),
                    ),
                ]
            )
        )
        self.features_bn = nn.Sequential(
            OrderedDict(
                [
                    ("norm2", nn.BatchNorm3d(num_init_features)),
                    ("relu2", nn.ReLU(inplace=True)),
                ]
            )
        )
        self.conv_pool_first = nn.Conv3d(
            num_init_features,
            num_init_features,
            kernel_size=2,
            stride=2,
            padding=0,
            bias=False,
        )

        # Each denseblock
        num_features = num_init_features
        self.dense_blocks = nn.ModuleList([])
        self.transit_blocks = nn.ModuleList([])
        self.upsampling_blocks = nn.ModuleList([])

        for i, num_layers in enumerate(block_config):
            block = _DenseBlock(
                num_layers=num_layers,
                num_input_features=num_features,
                bn_size=bn_size,
                growth_rate=growth_rate,
                drop_rate=drop_rate,
            )

            self.dense_blocks.append(block)

            num_features = num_features + num_layers * growth_rate

            up_block = nn.ConvTranspose3d(
                num_features,
                num_classes,
                kernel_size=2 ** (i + 1) + 2,
                stride=2 ** (i + 1),
                padding=1,
                groups=num_classes,
                bias=False,
            )

            self.upsampling_blocks.append(up_block)

            if i != len(block_config) - 1:
                trans = _Transition(
                    num_input_features=num_features,
                    num_output_features=num_features // 2,
                )
                self.transit_blocks.append(trans)
                # self.features.add_module('transition%d' % (i + 1), trans)
                num_features = num_features // 2

        # Final batch norm
        # self.features.add_module('norm5', nn.BatchNorm3d(num_features))

        # Linear layer
        # self.classifier = nn.Linear(num_features, num_classes)
        # self.bn4 = nn.BatchNorm3d(num_features)

        # ----------------------- classifier -----------------------
        self.bn_class = nn.BatchNorm3d(num_classes * 4 + num_init_features)
        self.conv_class = nn.Conv3d(
            num_classes * 4 + num_init_features, num_classes, kernel_size=1, padding=0
        )
        # ----------------------------------------------------------

        # Official init from torch repo.
        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                nn.init.kaiming_normal_(m.weight)
                # nn.Conv3d.bias.data.fill_(-0.1)
            elif isinstance(m, nn.BatchNorm3d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    """
    def forward(self, x):
        first_three_features = self.features(x)
        first_three_features_bn = self.features_bn(first_three_features)
        out = self.conv_pool_first(first_three_features_bn)

        out = self.dense_blocks[0](out)
        up_block1 = self.upsampling_blocks[0](out)
        out = self.transit_blocks[0](out)

        out = self.dense_blocks[1](out)
        up_block2 = self.upsampling_blocks[1](out)
        out = self.transit_blocks[1](out)

        out = self.dense_blocks[2](out)
        up_block3 = self.upsampling_blocks[2](out)
        out = self.transit_blocks[2](out)

        out = self.dense_blocks[3](out)
        up_block4 = self.upsampling_blocks[3](out)
        #
        out = torch.cat(
            [up_block1, up_block2, up_block3, up_block4, first_three_features], dim=1
        )

        # ----------------------- classifier -----------------------
        out = self.conv_class(F.relu(self.bn_class(out)))
        # ----------------------------------------------------------

        return out
    """

    def forward(self, x):
        (
            feature1,
            feature2,
            feature3,
            feature4,
            first_three_features,
        ) = self.feature_extraction(x)
        out = self.segmentation(
            feature1, feature2, feature3, feature4, first_three_features
        )
        return out

    def feature_extraction(self, x):
        first_three_features = self.features(x)
        first_three_features_bn = self.features_bn(first_three_features)
        out = self.conv_pool_first(first_three_features_bn)

        feature1 = self.dense_blocks[0](out)
        # up_block1 = self.upsampling_blocks[0](out)
        out = self.transit_blocks[0](feature1)

        feature2 = self.dense_blocks[1](out)
        # up_block2 = self.upsampling_blocks[1](out)
        out = self.transit_blocks[1](feature2)

        feature3 = self.dense_blocks[2](out)
        # up_block3 = self.upsampling_blocks[2](out)
        out = self.transit_blocks[2](feature3)

        feature4 = self.dense_blocks[3](out)
        # up_block4 = self.upsampling_blocks[3](out)
        #
        return feature1, feature2, feature3, feature4, first_three_features

    def segmentation(
        self, feature1, feature2, feature3, feature4, first_three_features
    ):
        up_block1 = self.upsampling_blocks[0](feature1)
        up_block2 = self.upsampling_blocks[1](feature2)
        up_block3 = self.upsampling_blocks[2](feature3)
        up_block4 = self.upsampling_blocks[3](feature4)
        out = torch.cat(
            [up_block1, up_block2, up_block3, up_block4, first_three_features], dim=1
        )
        # ----------------------- classifier -----------------------
        out = self.conv_class(F.relu(self.bn_class(out)))
        # ----------------------------------------------------------
        return out
